package com.BankingApplication.Service;

import com.BankingApplication.Common.APIResponse;
import com.BankingApplication.Common.Error;
import com.BankingApplication.Common.LoginRequestValidation;
import com.BankingApplication.DTO.LoginRequestDTO;
import com.BankingApplication.Entity.Customer;
import com.BankingApplication.Repository.CustomerRepository;
import com.BankingApplication.Utils.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class LoginService {

    @Autowired
    LoginRequestValidation loginRequestValidation;
    @Autowired
    APIResponse apiResponse;
    @Autowired
    CustomerRepository customerRepository;

    @Autowired
    JwtUtils jwtUtils;
//To login the existing user
    public APIResponse login(LoginRequestDTO loginRequestDTO) {


        List<Error> errors = LoginRequestValidation.validateLogin((LoginRequestDTO) loginRequestDTO);
        if (errors.isEmpty()) {
            Customer customer = customerRepository.findByNameAndPassword(loginRequestDTO.getName(), loginRequestDTO.getPassword());
            if (customer == null) {
                apiResponse.setStatus(400);
                apiResponse.setData(null);
                apiResponse.setMessage("Data not found");
            } else {
                String token = jwtUtils.generateJwt(customer);
                Map<String, Object> data = new HashMap<>();
                data.put("Token", token);
                apiResponse.setData(data);
                apiResponse.setMessage("Success");
                apiResponse.setStatus(200);
            }
        }
        else
        {
//generate jwt token
            apiResponse.setStatus(400);
            apiResponse.setData(errors);
            apiResponse.setMessage("login values can't be null");
        }

        return apiResponse;
    }
}
