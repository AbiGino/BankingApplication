//package com.BankingApplication.DTO;
//
//import com.BankingApplication.Entity.Account;
//import com.BankingApplication.Entity.Customer;
//import lombok.*;
//
//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
//@ToString
//public class NewAccountDTO {
//    private Account account;
//    private Customer customer;
//}
